import * as React from "react"
import { Frame, useCycle } from "framer"
import sketch from "./Sketch"
import P5Wrapper from "react-p5-wrapper"

export function P5(props) {
    return (
        <P5Wrapper
            sketch={sketch}
            alignValue={props.alignValue}
            cohesionValue={props.cohesionValue}
            separationValue={props.separationValue}
        />
    )
}

P5.defaultProps = {
    alignValue: 1,
    cohesionValue: 1,
    separationValue: 1,
}
