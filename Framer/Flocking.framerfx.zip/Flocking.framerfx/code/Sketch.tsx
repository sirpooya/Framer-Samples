import Boid from "./Boid"

export default function Sketch(p) {
    const flock = []
    // let alignSlider, cohesionSlider, separationSlider
    let alignValue = 1
    let cohesionValue = 1
    let separationValue = 1

    p.setup = () => {
        p.createCanvas(414, 715)

        for (let i = 0; i < 50; i++) {
            flock.push(new Boid(p, alignValue, cohesionValue, separationValue))
        }
    }

    p.myCustomRedrawAccordingToNewPropsHandler = function(props) {
        if (props.alignValue) {
            alignValue = props.alignValue
        }
        // alignValue = props.alignValue || null

        if (props.cohesionValue) {
            cohesionValue = props.cohesionValue
        }

        if (props.separationValue) {
            separationValue = props.separationValue
        }
    }

    p.draw = () => {
        p.background(0, 82, 204)
        for (let boid of flock) {
            boid.alignValue = alignValue
            boid.cohesionValue = cohesionValue
            boid.separationValue = separationValue
            boid.edges()
            boid.flock(flock)
            boid.update()
            boid.show()
        }
    }
}
