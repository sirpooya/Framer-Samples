import { Data, Override } from "framer"

const data = Data({
    alignValue: 1,
    cohesionValue: 1,
    separationValue: 1,
})

export function getAlign(): Override {
    return {
        onValueChange: value => {
            data.alignValue = value
        },
    }
}

export function getCohesion(): Override {
    return {
        onValueChange: value => {
            data.cohesionValue = value
        },
    }
}

export function getSeparation(): Override {
    return {
        onValueChange: value => {
            data.separationValue = value
        },
    }
}

export function setP5(): Override {
    return {
        alignValue: data.alignValue,
        cohesionValue: data.cohesionValue,
        separationValue: data.separationValue,
    }
}

export function setAlignText(): Override {
    return {
        text: data.alignValue,
    }
}

export function setCohesionText(): Override {
    return {
        text: data.cohesionValue,
    }
}

export function setSeparationText(): Override {
    return {
        text: data.separationValue,
    }
}
